function validate() {
    var key = document.querySelector('input[type="text"]').value;
    var price = document.querySelector('.number').value;
    if (key === '') {
        document.querySelector('.keyword').innerText = 'Trường này không được bỏ trống!';
        return false;
    } else {
        document.querySelector('.keyword').innerText = '';
    }

    if (price === '') {
        document.querySelector('.price-1').innerText = 'Trường này không được bỏ trống!';
        return false;
    } else if (isNaN(price)) {
        document.querySelector('.price-1').innerText = 'Trường này phải là số!';
        alert("gia phai la so")
        return false;
    } else {

        document.querySelector('.price-1').innerText = '';
        return false;
    }
}