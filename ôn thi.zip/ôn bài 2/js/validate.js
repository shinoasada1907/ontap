function validate() {
    var key = document.getElementById("nhap").value;
    var price = document.getElementById("min").value;
    var price1 = document.getElementById("max").value;
    if (key != "") {
        if (price == "") {
            if (price1 == "") {
                return true
            } else {
                if (isNaN(price1)) {
                    alert("Phần giá phải là số")
                    return false
                } else {
                    return true
                }
            }
        } else {
            if (isNaN(price)) {
                alert("Giá phải là số")
                return false
            } else {
                if (price1 == "") {
                    return true
                } else {
                    if (isNaN(price1)) {
                        alert("Phần giá phải là số")
                        return false
                    } else {
                        return true
                    }
                }
            }
        }
    } else {
        if (price == "") {
            if (price1 == "") {
                alert("Không được bỏ trống phần này")
                return false
            } else {
                if (isNaN(price1)) {
                    alert("Phần giá phải là số")
                    return false
                } else {
                    return true
                }
            }
        } else {
            if (isNaN(price)) {
                alert("Giá phải là số")
                return false
            } else {
                if (price1 == "") {
                    alert("Không được bỏ trống phần này")
                    return false
                } else {
                    if (isNaN(price1)) {
                        alert("Phần giá phải là số")
                        return false
                    } else {
                        return true
                    }
                }
            }
        }
    }
}